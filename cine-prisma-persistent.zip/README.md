# Cine (Next.js + Prisma + SQLite) — Persistente

Proyecto listo para desplegar con SQLite persistente usando Prisma ORM.

## Pasos para correr localmente

1. Instalar dependencias:
```bash
npm install
```

2. Generar cliente de Prisma y crear la DB:
```bash
npx prisma generate
npx prisma db push
node prisma/seed.js
```

3. Ejecutar la app:
```bash
npm run dev
```

Abre http://localhost:3000

## Notas para desplegar en Vercel
- Incluye la carpeta `prisma` y el archivo `prisma/database.db` si quieres que la DB venga pre-poblada.
- En Vercel, asegúrate de ejecutar `npx prisma generate` en los comandos de build.
- Considera usar una base de datos gestionada para producción si necesitas múltiples instancias.
