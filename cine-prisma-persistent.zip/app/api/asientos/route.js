import db from '../../../../prisma/server';

export async function GET(){
  const rows = await db.butaca.findMany({ orderBy: { label: 'asc' } });
  return new Response(JSON.stringify(rows), { status:200 });
}
