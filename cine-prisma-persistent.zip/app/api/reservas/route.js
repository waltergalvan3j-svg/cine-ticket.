import db from '../../../../prisma/server';
import { v4 as uuidv4 } from 'uuid';

export async function POST(req){
  try{
    const body = await req.json();
    const { seats } = body;
    if(!seats || seats.length===0) return new Response(JSON.stringify({ error: 'No seats' }), { status:400 });
    for(const s of seats){
      const b = await db.butaca.findUnique({ where: { label: s } });
      if(!b) return new Response(JSON.stringify({ error: `Butaca ${s} no existe`} ), { status:400 });
      if(b.reserved) return new Response(JSON.stringify({ error: `Butaca ${s} ya está reservada`} ), { status:409 });
    }
    for(const s of seats){
      await db.butaca.update({ where:{ label: s }, data: { reserved: true } });
    }
    const code = uuidv4();
    const ticket = await db.ticket.create({ data: { code, movie: 'Un Amor Inquebrantable', horario: '13 de septiembre · 6:30 PM', seats: JSON.stringify(seats), used:false } });
    return new Response(JSON.stringify({ ticket: { code: ticket.code, movie: ticket.movie, horario: ticket.horario, seats: JSON.parse(ticket.seats) }}), { status:200 });
  }catch(e){
    return new Response(JSON.stringify({ error: e.message }), { status:500 });
  }
}
