import db from '../../../../prisma/server';

export async function POST(req){
  try{
    const body = await req.json();
    const { code } = body;
    if(!code) return new Response(JSON.stringify({ ok:false, error:'Código vacío' }), { status:400 });
    const ticket = await db.ticket.findUnique({ where: { code } });
    if(!ticket) return new Response(JSON.stringify({ ok:false, error:'Ticket no encontrado' }), { status:404 });
    if(ticket.used) return new Response(JSON.stringify({ ok:false, error:'Ticket ya usado' }), { status:409 });
    await db.ticket.update({ where:{ code }, data: { used:true } });
    return new Response(JSON.stringify({ ok:true, msg:`Ticket válido para ${ticket.movie} - ${ticket.horario} - Asientos: ${ticket.seats}` }), { status:200 });
  }catch(e){
    return new Response(JSON.stringify({ ok:false, error: e.message }), { status:500 });
  }
}
