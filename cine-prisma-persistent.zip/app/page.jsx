"use client";
import Link from "next/link";

export default function Home(){
  return (
    <main style={{padding:24, fontFamily: "Inter, system-ui, sans-serif"}}>
      <h1 style={{fontSize:32}}>🎬 Un Amor Inquebrantable</h1>
      <p style={{marginTop:8}}>Película cristiana - Función: <strong>13 de septiembre · 6:30 PM</strong></p>
      <p style={{marginTop:12}}>Entrada gratuita. Reserva tu butaca y recibe tu ticket con QR.</p>
      <div style={{marginTop:20}}>
        <Link href="/asientos"><button style={{padding:"10px 16px", background:"#0ea5a4", color:"#fff", borderRadius:8, border:"none"}}>Reservar butacas</button></Link>
      </div>
    </main>
  );
}
