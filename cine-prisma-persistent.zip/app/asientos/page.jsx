"use client";
import { useEffect, useState, useMemo } from "react";
import QRCode from "react-qr-code";

export default function Asientos(){
  const [butacas, setButacas] = useState([]);
  const [selected, setSelected] = useState([]);
  const [ticket, setTicket] = useState(null);

  useEffect(()=>{ fetch('/api/asientos').then(r=>r.json()).then(setButacas); },[]);

  const seats = useMemo(()=> butacas, [butacas]);

  function toggle(label){
    if(selected.includes(label)) setSelected(selected.filter(s=>s!==label));
    else setSelected([...selected,label]);
  }

  async function reservar(){
    if(selected.length===0) return alert('Selecciona al menos 1 butaca');
    const res = await fetch('/api/reservas', { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({ seats:selected }) });
    const data = await res.json();
    if(res.ok){ setTicket(data.ticket); setButacas(butacas.map(b=> selected.includes(b.label)? {...b, reserved:true}: b)); setSelected([]); }
    else alert(data.error || 'Error');
  }

  return (
    <main style={{padding:24}}>
      <h2>Reservar butacas — Un Amor Inquebrantable</h2>
      <p>Función: <strong>13 de septiembre · 6:30 PM</strong></p>
      <div style={{marginTop:16, display:'grid', gridTemplateColumns:'repeat(6,1fr)', gap:8}}>
        {seats.map(b=> (
          <button key={b.label} disabled={b.reserved} onClick={()=>toggle(b.label)} style={{
            padding:10, borderRadius:8, border:'1px solid #ccc',
            background: b.reserved ? '#94a3b8' : (selected.includes(b.label)? '#10b981' : '#fff')
          }}>{b.label}</button>
        ))}
      </div>
      <div style={{marginTop:16}}>
        <button onClick={reservar} style={{padding:10, background:'#0ea5a4', color:'#fff', borderRadius:8}}>Confirmar reserva</button>
      </div>

      {ticket && (
        <div style={{marginTop:24, background:'#fff', color:'#111', padding:16, borderRadius:8, display:'inline-block'}}>
          <h3>Tu ticket</h3>
          <p><strong>{ticket.movie}</strong></p>
          <p>{ticket.horario}</p>
          <p>Asientos: {ticket.seats.join(', ')}</p>
          <div style={{background:'#fff', padding:8, display:'inline-block'}}><QRCode value={JSON.stringify(ticket)} size={160} /></div>
          <p style={{fontSize:12, color:'#555'}}>Código: {ticket.code}</p>
        </div>
      )}
    </main>
  );
}
