import { PrismaClient } from '@prisma/client';
const prisma = new PrismaClient();

async function main(){
  const labels = [];
  for(let i=1;i<=15;i++) labels.push(`A${i}`);
  for(let i=1;i<=15;i++) labels.push(`B${i}`);
  for(const label of labels){
    const exists = await prisma.butaca.findUnique({ where: { label } });
    if(!exists){
      await prisma.butaca.create({ data: { label } });
    }
  }
  console.log('Asientos creados/asegurados.');
}
main()
  .catch(e => { console.error(e); process.exit(1); })
  .finally(async () => { await prisma.$disconnect(); });
